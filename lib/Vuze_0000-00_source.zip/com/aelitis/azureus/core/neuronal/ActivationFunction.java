package com.aelitis.azureus.core.neuronal;

public interface ActivationFunction {
	
	public double getValueFor(double x);
	
	public double getDerivedFunctionValueFor(double x);

}
